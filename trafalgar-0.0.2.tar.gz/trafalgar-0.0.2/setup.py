from setuptools import setup

setup(
    name='trafalgar',
    version='0.0.2',
    description='Python library to make development of portfolio analysis faster and easier',
    py_modules=["Trafalgar"],
    package_dir={'':'src'},

)
